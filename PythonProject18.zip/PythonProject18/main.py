#!/usr/bin/env python
import math
import random

import pygame
#!/usr/bin/env python


# noinspection PyUnresolvedReferences
# import vtkmodules.vtkInteractionStyle
from vtkmodules.vtkInteractionStyle import vtkInteractorStyleTrackballCamera
from vtkmodules.vtkCommonCore import vtkDoubleArray
from vtkmodules.vtkCommonDataModel import vtkRectilinearGrid
import vtkmodules.vtkRenderingOpenGL2
from vtkmodules.vtkCommonColor import vtkNamedColors
from vtkmodules.vtkFiltersSources import (
    vtkConeSource,
    vtkCubeSource,
    vtkCylinderSource,
    vtkSphereSource
)
from vtkmodules.vtkRenderingCore import (
    vtkActor,
    vtkDataSetMapper,
    vtkPolyDataMapper,
    vtkRenderWindow,
    vtkRenderWindowInteractor,
    vtkRenderer, vtkCamera
)

def paintPointNumber(xin, yin, zin, gridin):
    b = [0, 0, 0]
    c = [0.0, 0.0, 0.0]
    a = gridin.ComputeStructuredCoordinates([xin, yin, zin], b, c)
    idp = None
    if a > 0:
        pcoord = [0.0, 0.0, 0.0]
        gridin.GetPoint(b[0], b[1], b[2], pcoord)
        idp = gridin.ComputePointId(b)
    return idp


def paintCirclePure(grid,scalars, r, val, dx, dy, dz=None):
    xSize = (grid.GetDimensions()[0])*dx
    ySize = (grid.GetDimensions()[1])*dy
    mindXY = dx
    if dy < dx:
        mindXY = dy
    x = 2*r + random.randint(0,100)* (xSize-2*r)/100
    y = 2*r + random.randint(0,100)* (ySize-2*r)/100
    z = 0

    px = [(x-4*r/5,y), (x-3*r/5,y), (x-2*r/5,y),(x-1*r/5,y), (x,y),(x-1*r/5,y), (x+2*r/5,y), (x+3*r/5,y), (x+4*r/5,y),
          (x-3*r/5,y+1*r/5), (x-2*r/5,y+1*r/5),(x-2*r/5,y+1*r/5), (x,y+1*r/5),
                                                              (x-2*r/5,y+1*r/5), (x+2*r/5,y+1*r/5), (x+3*r/5,y+1*r/5),
          (x-3*r/5,y+2*r/5),(x-2*r/5,y+2*r/5),(x-1*r/5,y+2*r/5), (x,y+2*r/5),
                       (x+1*r/5,y+2*r/5),(x+2*r/5,y+2*r/5),(x+3*r/5,y+2*r/5),
          (x-3*r/5,y+3*r/5),(x-2*r/5,y+3*r/5),(x-1*r/5,y+3*r/5), (x,y+3*r/5),
                       (x+1*r/5,y+3*r/5),(x+2*r/5,y+3*r/5),(x+3*r/5,y+3*r/5),
          (x-3*r/5,y-1*r/5), (x-2*r/5,y-1*r/5),(x-2*r/5,y-1*r/5), (x,y-1*r/5),
                                                              (x-2*r/5,y-1*r/5), (x+2*r/5,y-1*r/5), (x+3*r/5,y-1*r/5),
          (x-3*r/5,y-2*r/5),(x-2*r/5,y-2*r/5),(x-1*r/5,y-2*r/5), (x,y-2*r/5),
                       (x+1*r/5,y-2*r/5),(x+2*r/5,y-2*r/5),(x+3*r/5,y-2*r/5),
          (x-3*r/5,y-3*r/5),(x-2*r/5,y-3*r/5),(x-1*r/5,y-3*r/5), (x,y-3*r/5),
                       (x+1*r/5,y-3*r/5),(x+2*r/5,y-3*r/5),(x+3*r/5,y-3*r/5),


          ]
    for p in px:
        b = [0, 0, 0]
        c = [0.0, 0.0, 0.0]
        a = grid.ComputeStructuredCoordinates([p[0], p[1], z], b, c)
        if a>0:
            pcoord = [0.0, 0.0, 0.0]
            grid.GetPoint(b[0], b[1], b[2], pcoord)
            usl = math.sqrt((pcoord[0] - x) * (pcoord[0] - x) + (pcoord[1] - y) * (pcoord[1] - y))
            if usl <= r:
                idp = grid.ComputePointId(b)
                scalars.SetValue(idp, val)
    return scalars

# def paintCircleStrong(grid,scalars, r, val, dx, dy, dz=None):
def paintCircle(grid,scalars, r, val, dx, dy, dz=None):
    xSize = (grid.GetDimensions()[0])*dx
    ySize = (grid.GetDimensions()[1])*dy
    mindXY = dx
    if dy < dx:
        mindXY = dy
    x = 2*r + random.randint(0,100)* (xSize-2*r)/100
    y = 2*r + random.randint(0,100)* (ySize-2*r)/100
    z = 0

    counter = int(r / mindXY)
    for i in range(counter):
        yl = i*mindXY
        for j in range(counter):
            xl = j*mindXY
            usl = math.sqrt(xl*xl + yl*yl )
            if usl <= r:
                # b = [0, 0, 0]
                # c = [0.0, 0.0, 0.0]
                # a = grid.ComputeStructuredCoordinates([x+xl, y+yl, z], b, c)
                # if a > 0:
                #     pcoord = [0.0, 0.0, 0.0]
                #     grid.GetPoint(b[0], b[1], b[2], pcoord)
                #     usl = math.sqrt((pcoord[0] - x) * (pcoord[0] - x) + (pcoord[1] - y) * (pcoord[1] - y))
                #     if usl <= r:
                #         idp = grid.ComputePointId(b)
                #         scalars.SetValue(idp, val)
                idp = paintPointNumber(x+xl, y+yl, z, grid)
                if not idp is None:
                    scalars.SetValue(idp, val)
                idp = paintPointNumber(x+xl, y-yl, z, grid)
                if not idp is None:
                    scalars.SetValue(idp, val)
                idp = paintPointNumber(x-xl, y+yl, z, grid)
                if not idp is None:
                    scalars.SetValue(idp, val)
                idp = paintPointNumber(x-xl, y-yl, z, grid)
                if not idp is None:
                    scalars.SetValue(idp, val)

    # px = [(x-4*r/5,y), (x-2*r/5,y),(x,y),(x+2*r/5,y),(x+4*r/5,y),(x-3*r/5,y+2*r/5),(x,y+2*r/5),(x+3*r/5,y+2*r/5),
    #                                           (x,y+4*r/5),(x-3*r/5,y-2*r/5),(x,y-2*r/5),(x+3*r/5,y-2*r/5),(x,y-4*r/5),]
    # for p in px:
    #     b = [0, 0, 0]
    #     c = [0.0, 0.0, 0.0]
    #     a = grid.ComputeStructuredCoordinates([p[0], p[1], z], b, c)
    #     if a>0:
    #         pcoord = [0.0, 0.0, 0.0]
    #         grid.GetPoint(b[0], b[1], b[2], pcoord)
    #         usl = math.sqrt((pcoord[0] - x) * (pcoord[0] - x) + (pcoord[1] - y) * (pcoord[1] - y))
    #         if usl <= r:
    #             idp = grid.ComputePointId(b)
    #             scalars.SetValue(idp, val)
    return scalars

def main2():
    colors = vtkNamedColors()

    # Visualize
    renderer = vtkRenderer()
    renderWindow = vtkRenderWindow()
    renderWindow.AddRenderer(renderer)
    renderWindow.SetWindowName('RectilinearGrid')

    renderWindowInteractor = vtkRenderWindowInteractor()
    renderWindowInteractor.SetRenderWindow(renderWindow)

    # renderer.AddActor(actor)
    renderer.SetBackground(colors.GetColor3d('SlateGray'))

    renderWindow.Render()
    renderWindowInteractor.Start()


def main3():
    colors = vtkNamedColors()
    # Create a grid
    grid = vtkRectilinearGrid()

    # Размер панели, мм:
    LPanel = 9000
    HPanel = 300
    # сканируем вдоль длинной стороны
    # Количество ударов по направлениям:
    LPanelStrikeCount = 23400
    HPanelStrikeCount = 100

    grid.SetDimensions(LPanelStrikeCount , HPanelStrikeCount, 1)
    deltaX = LPanel/LPanelStrikeCount
    deltaY = HPanel/HPanelStrikeCount

    viewPortCounts = 3
    halfDeltaXforCamera = (LPanel/viewPortCounts)/2


    # сканируем вдоль короткой стороны (вид вертикально)
    # grid.SetDimensions(780, 3000, 1)
    # deltaX = 0.385
    # deltaY = 3.0

    # сканируем вдоль короткой стороны (вид горизонтально)
    # grid.SetDimensions(3000,780, 1)
    # deltaX = 3.0
    # deltaY = 0.385

    xSize = (grid.GetDimensions()[0])*deltaX
    xArray = vtkDoubleArray()
    val = 0.0 - deltaX
    for i in range(grid.GetDimensions()[0]):
        val += deltaX
        xArray.InsertNextValue(val)

    ySize = (grid.GetDimensions()[1])*deltaY
    yArray = vtkDoubleArray()
    valy = 0.0 - deltaY
    for i in range(grid.GetDimensions()[1]):
        valy += deltaY
        yArray.InsertNextValue(valy)

    zArray = vtkDoubleArray()
    delta = 2.0
    val = 0.0 - delta
    for i in range(grid.GetDimensions()[2]):
        val += delta
        zArray.InsertNextValue(val)

    # zArray.InsertNextValue(0.0)

    grid.SetXCoordinates(xArray)
    grid.SetYCoordinates(yArray)
    grid.SetZCoordinates(zArray)

    # print('There are', grid.GetNumberOfPoints(), 'points.')
    # print('There are', grid.GetNumberOfCells(), 'cells.')

    # for id in range(0, grid.GetNumberOfPoints()):
    #     p = [0] * 3
    #     p = grid.GetPoint(id)
        # print('Point', id, ':(', p[0], ',', p[1], ',', p[2], ')')

    scalars = vtkDoubleArray()
    scalars.SetName('MyScalars')
    for id in range(0, grid.GetNumberOfPoints()):
        p = grid.GetPoint(id)
        # scalars.InsertNextValue(0.5+ random.randint(0,100)/100*p[0]/xSize)
        valInsert =grid.GetPoint(   random.randint(0, grid.GetNumberOfPoints()) )
        scalars.InsertNextValue(valInsert[0]/xSize)


    rndz = 0.0
    r = 5.0
    val = -1.0*xSize
    paintCircle(grid, scalars, r, val, deltaX, deltaY, dz=0)
    paintCircle(grid, scalars, r, val, deltaX, deltaY, dz=0)

    # прорисуем границы вьюпортов
    for j in range(viewPortCounts):
        for i in range(HPanelStrikeCount):
            valInsert =100
            b = [0,0,0]
            c = [0.0,0.0,0.0]
            a = grid.ComputeStructuredCoordinates([(j+1) *2*halfDeltaXforCamera,i*deltaY,0.0],b,c)
            if a>0:
                # pcoord = [0.0,0.0,0.0]
                # p = grid.GetPoint(b[0],b[1],b[2],pcoord)
                idp = grid.ComputePointId(b)
                scalars.SetValue(idp+1, valInsert)
                scalars.SetValue(idp-1, valInsert)
                scalars.SetValue(idp, valInsert)

    grid.GetPointData().SetScalars(scalars)
    grid.Modified()

    # b = [0,0,0]
    # c = [0.0,0.0,0.0]
    # a = grid.ComputeStructuredCoordinates([xSize/2,ySize/2,0.0],b,c)
    # pcoord = [0.0,0.0,0.0]
    # p = grid.GetPoint(b[0],b[1],b[2],pcoord)
    # idp = grid.ComputePointId(b)

    # Create a mapper and actor
    mapper = vtkDataSetMapper()
    mapper.SetInputData(grid)
    # mapper.Update()

    mapper.ScalarVisibilityOn()
    mapper.SetColorModeToMapScalars()
    ## mapper.SetScalarRange(0, 20);
    # mapper.Update()

    actor = vtkActor()
    actor.SetMapper(mapper)
    actor.GetProperty().SetColor(colors.GetColor3d('PeachPuff'))

    # One render window, multiple viewports.
    rw = vtkRenderWindow()
    iren = vtkRenderWindowInteractor()
    iren.SetRenderWindow(rw)


    # Define 3 viewport ranges.
    xmins = [0, 0, 0, 0]
    xmaxs = [1, 1, 1, 1]
    ymins = [0, 0.3, .6, .9]
    ymaxs = [0.3, 0.6, 0.9, 1]
    # Have some fun with colors.
    # ren_bkg = ['AliceBlue', 'GhostWhite', 'AliceBlue','WhiteSmoke']
    ren_bkg = ['LightGrey', 'Grey', 'LightGrey','Grey']
    actor_color = ['LightBlue', 'RosyBrown', 'Goldenrod', 'Chocolate']
    # camera_position_X = [8000, 5000, 1800 , 4900]
    # camera_position_Y = 150

    camera_position_X = [halfDeltaXforCamera,3*halfDeltaXforCamera, 5*halfDeltaXforCamera, LPanel/2]
    camera_position_Y = HPanel/2

    camera_height = [900, 900, 900 , 900]

    # # Define N viewport ranges.
    # xmins = [0.0, 0.0, 0.0, 0.0, 0.0]
    # xmaxs = [1.0, 1.0, 1.0, 1.0, 1.0]
    # ymins = [0.0, 0.25, 0.50, 0.75, 1.0]
    # ymaxs = [0.25, 0.50, 0.75, 1.0, 1.0]
    # # Have some fun with colors.
    # # ren_bkg = ['AliceBlue', 'GhostWhite', 'AliceBlue','WhiteSmoke']
    # ren_bkg = ['LightGrey', 'Grey', 'LightGrey','Grey', 'LightGrey']
    # actor_color = ['LightBlue', 'RosyBrown', 'Goldenrod', 'Chocolate', 'Goldenrod']
    # camera_position_X = [halfDeltaXforCamera,3*halfDeltaXforCamera, 5*halfDeltaXforCamera, 7*halfDeltaXforCamera , LPanel/2]
    # camera_position_Y = HPanel/2
    # camera_height = [700, 700, 700, 700 , 700]

    deltaCameraPosition = 100
    cameraPosition = 0

    # # Create a mapper and actor
    # mapper = vtkPolyDataMapper()
    # mapper.SetInputConnection(sources[3].GetOutputPort())
    # actor = vtkActor()
    # actor.GetProperty().SetColor(colors.GetColor3d(actor_color[3]))
    # actor.RotateZ(90.0)
    # actor.SetMapper(mapper)

    for i in range(len(xmins)):
        ren = vtkRenderer()
        ren.SetViewport(xmins[i], ymins[i], xmaxs[i], ymaxs[i])
        rw.AddRenderer(ren)
        camera = vtkCamera()
        # camera = ren.GetActiveCamera()

        # Share the camera between viewports.
        # cameraPosition += deltaCameraPosition
        camera.SetFocalPoint(camera_position_X[i],  camera_position_Y, 0)
        camera.SetPosition(camera_position_X[i], camera_position_Y, camera_height[i])
        # camera.SetScreenBottomLeft(camera_position_X[i]-halfDeltaXforCamera,0.0,0.0)
        # camera.SetScreenTopRight(camera_position_X[i]+halfDeltaXforCamera,HPanel,0.0)
        # camera.ResetClippingRange()

        # camera.Azimuth(30)
        # camera.Elevation(30)

        # camera = ren.GetActiveCamera();
        # camera.SetRoll(15);
        # camera.Elevation(-15);
        # camera.Azimuth(30);
        # camera.SetViewUp(0.623411, 0.573532, -0.531431);
        # camera.SetDistance(6.727500);
        # camera.SetClippingRange(3.001430, 11.434082);
        # ren.ResetCamera();
        # renWin.Render();
        # // No need to use ren.ResetCamera() as we have all the parameters.
        # renWin.Render();

        ren.SetActiveCamera(camera)

        ren.AddActor(actor)
        ren.SetBackground(colors.GetColor3d(ren_bkg[i]))
        # ren.ResetCamera()
    rw.SetSize(2500, 1300)
    rw.SetWindowName('900cmx30cm')
    rw.Render()
    # rr = rw.GetRenderers()
    # print(rr.GetNumberOfItems())
    iren.Start()


# if __name__ == '__main__':
#     main()


def get_program_parameters():
    import argparse
    description = 'Display multiple render windows.'
    epilogue = '''
    '''
    parser = argparse.ArgumentParser(description=description, epilog=epilogue,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('-s', default=False, action='store_true',
                        help='Simultaneous camera position updating.')
    args = parser.parse_args()
    return args.s


def main():
    simultaneous_update = get_program_parameters()

    colors = vtkNamedColors()
    # Have some fun with colors
    ren_bkg = ['AliceBlue', 'GhostWhite', 'WhiteSmoke', 'Seashell']
    actor_color = ['Bisque', 'RosyBrown', 'Goldenrod', 'Chocolate']

    # Window sizes and spacing.
    width = 300
    height = 300
    # Add extra space around each window.
    dx = 20
    dy = 40
    w = width + dx
    h = height + dy

    interactors = list()
    running = [True, True, True, True]

    camera = None
    sources = get_sources()

    kpis = list()
    for i in range(0, 4):
        ren_win = vtkRenderWindow()
        ren_win.SetSize(width, height)

        renderer = vtkRenderer()

        # Share the camera between viewports.
        if i == 0:
            camera = renderer.GetActiveCamera()
            camera.Azimuth(30)
            camera.Elevation(30)
        else:
            renderer.SetActiveCamera(camera)

        ren_win.AddRenderer(renderer)

        iren = vtkRenderWindowInteractor()

        interactors.append(iren)

        iren.SetRenderWindow(ren_win)
        ren_win.Render()
        ren_win.SetWindowName('MultipleRenderWindows {:d}'.format(i))
        ren_win.SetPosition((i % 2) * w, h - (i // 2) * h)

        # Create a mapper and actor.
        mapper = vtkPolyDataMapper()
        mapper.SetInputConnection(sources[i].GetOutputPort())

        actor = vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(colors.GetColor3d(actor_color[i]))

        renderer.AddActor(actor)
        renderer.SetBackground(colors.GetColor3d(ren_bkg[i]))

        renderer.ResetCamera()

        running[i] = True
        kpis.append(KeyPressInteractorStyle(parent=iren))
        interactors[i].SetInteractorStyle(kpis[i])
        kpis[i].status = running[i]

    if simultaneous_update:
        interactors[0].Initialize()
        while all(x is True for x in running):
            for i in range(0, 4):
                running[i] = kpis[i].status
                if running[i]:
                    interactors[i].ProcessEvents()
                    interactors[i].Render()
                else:
                    interactors[i].TerminateApp()
                    print('Window', i, 'has stopped running.')
    else:
        interactors[0].Start()


def get_sources():
    sources = list()

    # Create a sphere
    sphere = vtkSphereSource()
    sphere.SetCenter(0.0, 0.0, 0.0)
    sphere.Update()
    sources.append(sphere)
    # Create a cone
    cone = vtkConeSource()
    cone.SetCenter(0.0, 0.0, 0.0)
    cone.SetDirection(0, 1, 0)
    cone.Update()
    sources.append(cone)
    # Create a cube
    cube = vtkCubeSource()
    cube.SetCenter(0.0, 0.0, 0.0)
    cube.Update()
    sources.append(cube)
    # Create a cylinder
    cylinder = vtkCylinderSource()
    cylinder.SetCenter(0.0, 0.0, 0.0)
    cylinder.Update()
    sources.append(cylinder)

    return sources


class KeyPressInteractorStyle(vtkInteractorStyleTrackballCamera):

    def __init__(self, parent=None, status=True):
        self.parent = vtkRenderWindowInteractor()
        self.status = status
        if parent is not None:
            self.parent = parent

        self.AddObserver('KeyPressEvent', self.key_press_event)

    def key_press_event(self, obj, event):
        key = self.parent.GetKeySym().lower()
        if key == 'e' or key == 'q':
            self.status = False
        return


if __name__ == '__main__':
    # пробуем играть музыку
    pygame.mixer.pre_init(frequency=48000, size=-16, channels=2, buffer=512)
    pygame.mixer.init()
    pygame.mixer.music.load("d:\\dump Stuchalka\\wav_krai3\\line-29.wav")
    #pygame.mixer.music.load("music.mp3")
    pygame.mixer.music.play()
    # while pygame.mixer.music.get_busy():
    #     pass
    # end пробуем играть музыку
    main3()
